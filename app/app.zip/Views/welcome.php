<html>
<head><title>Welcome Message</title>
	<meta name="viewport" content="with=device-width; initial-scale=1.0">
	<meta charset="utf-8">
	<link rel="stylesheet" href="<?php echo BASE_URL;?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo BASE_URL;?>assets/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo BASE_URL;?>assets/fontawesome-free/css/all.min.css">
</head>
<body>
	<h2>Welcome to Lawliet Zero Framework</h2>
	<p>this controller can be found at app/Controllers/Welcome.php</p>
	<p>Read the documentation to use</p>
</body>
<script src="<?php echo BASE_URL;?>assets/js/jquery.min.js"></script>
<script src="<?php echo BASE_URL;?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_URL;?>assets/js/popper.js"></script>
<script src="<?php echo BASE_URL;?>assets/js/dataTables.bootstrap4.min.js"></script>
</html>