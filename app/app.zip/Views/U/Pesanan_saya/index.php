<html>
<head>
	<?php $this->view("__partials/head");?>
	<?php $this->view("U/Pesanan_saya/__partials/css");?>
</head>
<body>
	<?php $this->view("U/menu");?>
	<?php 
	$this->view("U/Header",$data["user_header"]);
	?>

	<div class="row m-2 lozad">

			<?php $this->view("U/menu_2");?>
		<!-- Dibawah adalah komponen menu sidebar !-->
		<!-- Dibawah adalah komponen utama !-->
		<div class="col-lg-8 col-md-8 col-xl-8 col-sm-8">	
			<?php if(isset($_SESSION["flash"])){
								echo "<br>".$_SESSION["flash"];
								unset($_SESSION["flash"]);
						 	}?>
						 	<div class="card">
						 		<div class="card-header"><h2>Data Pesanan Saya</h2></div>
						 		<div class="card-body">
						<table class="table table-bordered col-md-8 table-responsive" id="dataTable" width="100%" cellspacing="0">
							<thead>
			                  <tr>
			                    <th>Nama Paket</th>
			                    <th>Alamat Pemesan</th>
			                    <th>Nomor Telepon</th>
			                    <th>Email Pemesan</th>
			                    <th>Tanggal Pemesanan</th>
			                    <th>Tanggal Acara</th>
			                    <th>Kontrol</th>
			                  </tr>
	                		</thead>
			                <tfoot>
			                  <tr>
			                    <th>Nama Paket</th>
			                    <th>Alamat Pemesan</th>
			                    <th>Nomor Telepon</th>
			                    <th>Email Pemesan</th>
			                    <th>Tanggal Pemesanan</th>
			                    <th>Tanggal Acara</th>
			                    <th>Kontrol</th>
			                  </tr>
			                </tfoot>
	                		<tbody>
								<?php foreach ($data["pesanan"] as $dt) {?>
								  <tr>
				                    <td><?php echo $dt["nm_pkt"];?></td>
				                    <td><?php echo $dt["alt_pes"];?></td>
				                    <td><?php echo $dt["notel"];?></td>
				                    <td><?php echo $dt["email"];?></td>
				                    <td><?php echo $dt["tgl_pes"];?></td>
				                    <td><?php echo $dt["tgl_acara"];?></td>
				                    <td><a  class="text-primary btn btn-small cmd-edit" href="?a=U/Pesanan_saya/preview&&key=<?php echo $dt["id_pesanan"];?>" title="Preview data"><i class="fas fa-search"></i></a>   
				                    	<?php if($dt["status_pes"]==0){?>
				                    	<a class="text-danger btn btn-small" href="?a=U/Pesanan_saya/delete&&key=<?php echo $dt["id_pesanan"];?>" title="Batalkan Pemesanan"><i class="fas fa-trash"></i></a>
				                    	<?php }?></td>
				                  </tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
		</div>
	</div>
<?php $this->view("footer");?>
<?php $this->view("__partials/js");?>
<?php $this->view("U/Pesanan_saya/__partials/js");?>
</body>
</html>