<title>MAHKOTA PELAMINAN</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo BASE_URL."assets/css/bootstrap.min.css";?>">
	<link rel="stylesheet" href="<?php echo BASE_URL."assets/fontawesome-free/css/all.min.css";?>">
	<link rel="stylesheet" href="<?php echo BASE_URL."assets/summernote/summernote.css";?>">
	<link rel="stylesheet" href="<?php echo BASE_URL."assets/css/dataTables.bootstrap4.min.css";?>">