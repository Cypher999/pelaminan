<script src="<?php echo BASE_URL."assets/js/jquery.min.js";?>"></script>
<script src="<?php echo BASE_URL."assets/js/config.js";?>"></script>
<script src="<?php echo BASE_URL."assets/js/popper.js";?>"></script>
<script src="<?php echo BASE_URL."assets/js/bootstrap.bundle.min.js";?>"></script>
<script src="<?php echo BASE_URL."assets/fontawesome-free/js/all.min.js";?>"></script>
<script src="<?php echo BASE_URL."assets/js/lozad.min.js";?>"></script>
<script src="<?php echo BASE_URL."assets/summernote/summernote.min.js";?>"></script>
<script src="<?php echo BASE_URL."assets/js/jquery.dataTables.min.js";?>"></script>
<script src="<?php echo BASE_URL."assets/js/dataTables.bootstrap4.min.js";?>"></script>
<script>
	const obs=lozad();
	var count_text=1;
	obs.observe();
	
	
</script>