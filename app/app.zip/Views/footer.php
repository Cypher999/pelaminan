<div class="row pl-4 mt-2 " style="background-color:#00CED1">
			<div class="col-lg-12 mt-4 mb-4">
				<div class="row">
					<div class="col-lg-5 mb-2 mr-2">
						Copyright : <?php echo date('Y');?> by Mahkota Pelaminan
					</div>
					<div class="col-lg-5 mb-2 mr-2">
						<p>Follow Us On Social Media</p>
						<ul style="list-style-type:none">
							<li>Instagram :mahkotapelaminan_lola</li>
							<li>Facebook : mahkotapelaminan</li>
						</ul>
					</div>
				</div>
			</div>
		</div>