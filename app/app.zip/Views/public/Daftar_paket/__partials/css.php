<style>		
		.header
			{
			  /* The image used */
			  background-image: url("");

			  /* Add the blur effect */
			  filter: blur(2px);
			  -webkit-filter: blur(2px);
			  height: 90%;
			  width:100%;
			  /* Full height */

			  /* Center and scale the image nicely */
			  background-position: center;
			  background-repeat: no-repeat;
			  background-size: cover;
			}

			/* Position text in the middle of the page/image */
		.text-header
			{
				 background-color: rgb(0,0,0); /* Fallback color */
				  background-color: rgba(0,0,0, 0.4); /* Black w/opacity/see-through */
				  color: white;
				  font-weight: bold;
				  position: absolute;
				  top: 40%;
				  left: 50%;
				  transform: translate(-50%, -50%);
				  z-index: 2;
				  width: 80%;
				  padding: 20px;
				  text-align: center;
			  
			}

			/* Position text in the middle of the page/image */
			
		
	</style>