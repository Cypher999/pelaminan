
<div class="row pl-4 mb-2" style="background-color:#00CED1">
			<div class="col-lg-12">
				<div class="row mt-4 mb-4">
					<div class="col-lg-1">
						<img src="<?php echo BASE_URL;?>files/web_photo/logo.jpg" width="100" height="100">
					</div>
					<div class="col-lg-7">
						<h2 style="font-weight: bold;color:white">MAHKOTA PELAMINAN</h2>	
						<p style="font-weight: bold;color:white">JL Depati Raja Mudo, Kemantan Mudik, Kemantan Darat, Air Hangat Tim., Kabupaten Kerinci, Jambi 37161</p>								
					</div>
					<div class="col-lg-2 pt-3 " style="font-weight: bold;color:white;font-size: 24">
						<div class="row">
							<div class="col-sm-1 pt-2">
								<i class="fas fa-user"></i>
							</div>
							<div class="col-sm-6">
								Guess
							</div>						
						</div>
					</div>
				</div>
			</div>
		</div>