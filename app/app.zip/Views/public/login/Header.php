
<div class="row pl-4 mb-2" style="background-color:#00CED1">
			<div class="col-lg-12">
				<div class="row mt-4 mb-4">
					<div class="col-lg-1">
						<img src="img/logo.jpg" width="100" height="100">
					</div>
					<div class="col-lg-7">
						<h2 style="font-weight: bold;color:white">MAHKOTA PELAMINAN</h2>	
						<p style="font-weight: bold;color:white">jln. Muradi No. 11, Simpang RSUD H.A. thalib Kota Sungai Penuh HP 0813 6691 1599 / 0813 2940 5772</p>								
					</div>
				</div>
			</div>
		</div>