<div class="col-lg-3" style="background-color: gray">
				<div class="m-3">
					<div class='row'>
						<div class="col-lg-12 p-3 rounded-top" style="background-color:#00CED1;">
							<a href="<?php echo BASE_URL;?>"><h6 align="middle" style="color:white;font-weight: bold">HOME</h6></a>
						</div>
					</div>
					<div class='row rounded-bottom' style="background-color: white">
		<ul  data-spy="affix" data-offset-top="205" style="list-style-type: none;">
				<li>
					<a href="<?php echo BASE_URL."?a=Daftar_paket";?>"><button class="btn">Daftar Paket</button></a>
				</li>
				<li>
					<a href="<?php echo BASE_URL."?a=Home/login";?>"><button class="btn">Login</button></a>
				</li>
				<li>
					<a href="<?php echo BASE_URL."?a=Home/signup";?>"><button class="btn">Sign Up</button></a>
				</li>
			</ul>
		</div>
	</div>
</div>