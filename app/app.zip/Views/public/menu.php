<nav class="navbar mn1 navbar-expand-md navbar-dark" style="width: 100%;background-color:#00CED1;z-index:1000;position: fixed;top:0%;display:none">
		<a class="navbar-brand" href="<?php echo BASE_URL;?>">Mahkota Pelaminan </a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsiblenavbar_1">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="collapsiblenavbar_1">
			<ul class="navbar-nav">			
				<li class="nav-item">
					<div class="nav-link">
						<a class="btn" href="<?php echo BASE_URL."?a=Daftar_paket/";?>"> Daftar Paket</a>
					</div>
				</li>				
				<li class="nav-item">
					<div class="nav-link">
						<a class="btn" href="<?php echo BASE_URL."?a=Home/login";?>">Login</a>
					</div>
				</li>
				<li class="nav-item">
					<div class="nav-link">
						<a class="btn" href="<?php echo BASE_URL."?a=Home/signup";?>">Sign Up</a>
					</div>
				</li>
			</ul>
		</div>
	</nav>